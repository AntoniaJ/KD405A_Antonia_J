
public class Dog {
	
	private String name;
	
	public Dog(String name){
		this.name =  name;
	}
		
	public String getName(){
			return name;
		}
		
		
	/**
		if (Human.getName().length()>3){
			Dog.name = name;
		}else{
				Dog.name = "Cant print name";}
		}
	
*/
		
	


}
	
	
	



